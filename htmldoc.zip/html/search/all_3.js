var searchData=
[
  ['discriminant_0',['discriminant',['../_solve_equation_8cpp.html#a2876dcc4846e2235854a720d47131b88',1,'discriminant(double a, double b, double c):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#a2876dcc4846e2235854a720d47131b88',1,'discriminant(double a, double b, double c):&#160;SolveEquation.cpp']]]
];
