var searchData=
[
  ['fail_0',['fail',['../_unit_test_equation_8cpp.html#a1f852f6399d86f2f2c9f0d549a624e4f',1,'fail(int x, FailReasons_t reason, NumberOfRoots_t nRoots, double ans1, double ans2, NumberOfRoots_t expectedNRoots, double expectedAns1, double expectedAns2):&#160;UnitTestEquation.cpp'],['../_unit_test_equation_8h.html#a1f852f6399d86f2f2c9f0d549a624e4f',1,'fail(int x, FailReasons_t reason, NumberOfRoots_t nRoots, double ans1, double ans2, NumberOfRoots_t expectedNRoots, double expectedAns1, double expectedAns2):&#160;UnitTestEquation.cpp']]]
];
