var searchData=
[
  ['solveequation_2ecpp_0',['SolveEquation.cpp',['../_solve_equation_8cpp.html',1,'']]],
  ['solveequation_2eh_1',['SolveEquation.h',['../_solve_equation_8h.html',1,'']]]
];
