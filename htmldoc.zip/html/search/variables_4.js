var searchData=
[
  ['nroots_0',['nRoots',['../struct_test__case.html#a64dc96d0cd37f2da8e6124d56f2b9845',1,'Test_case']]]
];
