var searchData=
[
  ['inf_5froots_0',['INF_ROOTS',['../enumber_of_roots_8h.html#a0e5020f18cd040ca8a3f2ac8789b0d5ca5a79e9e49077da58fe5d46a98f0b5e36',1,'enumberOfRoots.h']]],
  ['inputcoefficients_1',['inputCoefficients',['../_solve_equation_8cpp.html#a84b43a7ba58283cd959ebad887944e9c',1,'inputCoefficients(double *a, double *b, double *c):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#a84b43a7ba58283cd959ebad887944e9c',1,'inputCoefficients(double *a, double *b, double *c):&#160;SolveEquation.cpp']]]
];
