var searchData=
[
  ['skipline_0',['skipLine',['../_unit_test_equation_8cpp.html#ae728880163215dabafd49ff3ac0573f5',1,'skipLine(FILE *fp):&#160;UnitTestEquation.cpp'],['../_unit_test_equation_8h.html#ae728880163215dabafd49ff3ac0573f5',1,'skipLine(FILE *fp):&#160;UnitTestEquation.cpp']]],
  ['solve_1',['SOLVE',['../main_8cpp.html#a808b41e4ebcfcf6cd6b2ad9ee7e6085bab9fc7975179c642bbac2b6ffd8fa3579',1,'main.cpp']]],
  ['solveequation_2ecpp_2',['SolveEquation.cpp',['../_solve_equation_8cpp.html',1,'']]],
  ['solveequation_2eh_3',['SolveEquation.h',['../_solve_equation_8h.html',1,'']]],
  ['solvelinear_4',['solveLinear',['../_solve_equation_8cpp.html#a5792a08c7d5cd52a25f8411e8883a564',1,'solveLinear(double a, double b, double *ans):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#a5792a08c7d5cd52a25f8411e8883a564',1,'solveLinear(double a, double b, double *ans):&#160;SolveEquation.cpp']]],
  ['solvesquare_5',['solveSquare',['../_solve_equation_8cpp.html#a214ed9ba941aa4d83b7a619c8adf473e',1,'solveSquare(double a, double b, double c, double *x1, double *x2):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#a214ed9ba941aa4d83b7a619c8adf473e',1,'solveSquare(double a, double b, double c, double *x1, double *x2):&#160;SolveEquation.cpp']]],
  ['sprintanswer_6',['sPrintAnswer',['../_solve_equation_8cpp.html#a2a53ec474004799b57b24e75dedc8abf',1,'sPrintAnswer(char *target, NumberOfRoots_t nRoots, double root1, double root2):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#a2a53ec474004799b57b24e75dedc8abf',1,'sPrintAnswer(char *target, NumberOfRoots_t nRoots, double root1, double root2):&#160;SolveEquation.cpp']]],
  ['standarttestequation_7',['StandartTestEquation',['../_unit_test_equation_8cpp.html#ad82be3bb024e3f97fd11701989a45406',1,'StandartTestEquation():&#160;UnitTestEquation.cpp'],['../_unit_test_equation_8h.html#ad82be3bb024e3f97fd11701989a45406',1,'StandartTestEquation():&#160;UnitTestEquation.cpp']]]
];
