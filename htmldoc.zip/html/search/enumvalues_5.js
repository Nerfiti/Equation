var searchData=
[
  ['two_5froots_0',['TWO_ROOTS',['../enumber_of_roots_8h.html#a0e5020f18cd040ca8a3f2ac8789b0d5ca876622d3c0b008da13a3685c64714e81',1,'enumberOfRoots.h']]]
];
