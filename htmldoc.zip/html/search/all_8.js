var searchData=
[
  ['no_5froots_0',['NO_ROOTS',['../enumber_of_roots_8h.html#a0e5020f18cd040ca8a3f2ac8789b0d5cab9a321da349ac1355b717745736ad90c',1,'enumberOfRoots.h']]],
  ['nroots_1',['nRoots',['../struct_test__case.html#a64dc96d0cd37f2da8e6124d56f2b9845',1,'Test_case']]],
  ['numberofroots_5ft_2',['NumberOfRoots_t',['../enumber_of_roots_8h.html#a0e5020f18cd040ca8a3f2ac8789b0d5c',1,'enumberOfRoots.h']]]
];
