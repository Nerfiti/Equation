var searchData=
[
  ['solve_0',['SOLVE',['../main_8cpp.html#a808b41e4ebcfcf6cd6b2ad9ee7e6085bab9fc7975179c642bbac2b6ffd8fa3579',1,'main.cpp']]]
];
