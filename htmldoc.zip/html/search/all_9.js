var searchData=
[
  ['one_5froot_0',['ONE_ROOT',['../enumber_of_roots_8h.html#a0e5020f18cd040ca8a3f2ac8789b0d5ca6700c0f6efd23571cb22aefd2510b1cf',1,'enumberOfRoots.h']]]
];
