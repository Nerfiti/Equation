var indexSectionsWithContent =
{
  0: "abcdefimnoprstuw",
  1: "t",
  2: "emsu",
  3: "acdfimprst",
  4: "abcen",
  5: "fnp",
  6: "inorstuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

