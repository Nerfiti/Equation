var searchData=
[
  ['printanswer_0',['printAnswer',['../_solve_equation_8cpp.html#af54842356f9c1f59cba96b050c2f82ca',1,'printAnswer(NumberOfRoots_t nRoots, double root1, double root2):&#160;SolveEquation.cpp'],['../_solve_equation_8h.html#af54842356f9c1f59cba96b050c2f82ca',1,'printAnswer(NumberOfRoots_t nRoots, double root1, double root2):&#160;SolveEquation.cpp']]]
];
