var searchData=
[
  ['enumberofroots_2eh_0',['enumberOfRoots.h',['../enumber_of_roots_8h.html',1,'']]]
];
